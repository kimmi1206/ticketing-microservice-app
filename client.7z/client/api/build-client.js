import axios from 'axios';

export default ({ req }) => {
  if (typeof window === 'undefined') {
    // we are executing on the server
    // const serviceName = 'ingress-nginx-controller';
    // const namespace = 'ingress-nginx';

    return axios.create({
      baseURL: 'http://localhost:3001',
      // baseURL: `http://${serviceName}.${namespace}.svc.cluster.local`,
      headers: req.headers,
    });
  } else {
    // we are on the client
    return axios.create({
      baseURL: 'http://localhost:3001',
    });
  }
};
